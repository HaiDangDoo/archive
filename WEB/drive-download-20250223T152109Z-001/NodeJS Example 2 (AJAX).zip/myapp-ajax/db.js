const mysql = require("mysql");

const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "classicmodels"
});

con.connect(function(err){
    if(err) throw err;
    console.log("Connected to MySQL DB successfully!");
})

module.exports = con;