const express = require("express");
// const bodyParser = require("body-parser");
const multer = require("multer");
const con = require("./db");
const upload = multer();

const app = express();
const PORT = 8080;

app.use(express.static('public'));

// Use multer middleware to parse form-data (multipart/form-data) 
app.use(upload.none());
app.set("view engine", "ejs");

const countries = ['USA', "Canada", "UK"];

app.get("/", function(req, res){
    res.render("index", {countries: countries, slCountry: ""})
});

// Respond to ajax request
app.post("/getCustomers", function(req, res){
    const slCountry = req.body.slCountry;
    const sql = "select customerName as name, phone from customers where country=?";
    con.query(sql, [slCountry], function(err, results){
        if(err) throw err;
        res.render("customerTable", {customers:results})
    });
});

app.listen(PORT, "127.0.0.1", function(){
    console.log(`Express App running at http://127.0.0.1:${PORT}`)
});