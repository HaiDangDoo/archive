const express = require("express");
const db = require("./db");
const bodyParser = require("body-parser");

const app = express();

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: false}));

const PORT = 9000;
const countries = ["USA", "UK", "Canada"];

app.use(express.static("public"));

// Route to "/"
app.get("/", function(req, res){
    res.render("index", {countries: countries, slCountry: ""})
})

app.post("/get_customers", function(req, res){
    const slCountry = req.body.slCountry;
    const sql = "SELECT customerName as name, phone FROM customers WHERE country=?";
    db.query(sql, [slCountry], function(err, results, fields){
        res.render("index", {customers: results, slCountry: slCountry, countries: countries})
    });
});

app.listen(PORT, function(){
    console.log(`Server running at: http://localhost:${PORT}`);
})